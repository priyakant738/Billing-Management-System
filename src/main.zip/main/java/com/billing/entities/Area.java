package com.billing.entities;

import javax.persistence.*;

@Entity
@Table(name = "Area"  , uniqueConstraints={
	    @UniqueConstraint(columnNames = {"area_Code", "area_Name"})
	})

public class Area extends BaseClass<String>{
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@JoinColumn(name="area_Id")
	private Long areaid;
	
	@ManyToOne
	@JoinColumn(name="city")
	private City cityid;
	
	@Column(name ="area_Code")
	private Long areaCode;
	
	@Column(name ="area_Name")
	private String areaName;

	public Long getAreaid() {
		return areaid;
	}

	public void setAreaid(Long areaid) {
		this.areaid = areaid;
	}

	public City getCity() {
		return cityid;
	}

	public void setCity(City city) {
		this.cityid = city;
	}

	public Long getAreaCode() {
		return areaCode;
	}

	public void setAreaCode(Long areaCode) {
		this.areaCode = areaCode;
	}

	public City getCityid() {
		return cityid;
	}

	public void setCityid(City cityid) {
		this.cityid = cityid;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	

	

	
	
	

}
