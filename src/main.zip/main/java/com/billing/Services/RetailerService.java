package com.billing.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billing.Repository.RetailerRepository;
import com.billing.entities.Retailer;

@Service
public class RetailerService {
	
	@Autowired
	private RetailerRepository retailerRepository;
	
	public List<Retailer> getAllRetailer()
	{
		List<Retailer> list=(List<Retailer>)this.retailerRepository.findAll();
		return list;
		
	}
	
	//get the single Retailer by id
	
	public Retailer getRetailerByid(Long id)
	{
		
		Retailer retailer=null;
		try 
		{
			retailer = this.retailerRepository.getById(id);
			 
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return retailer;
		
	}
	
	  //Adding the Retailer
	
	   public Retailer addRetailer(Retailer r)
	  {
		Retailer result=retailerRepository.save(r);
		return result;
    
	  }
	
	        //delete Retailer
	   
			public void deleteRetailer(Long rid)
			{
				retailerRepository.deleteById(rid);
			}
			
			//update the Retailer
			
			public Retailer updateRetailer(Retailer retailer, Long id)
			{
				
				Retailer list= retailerRepository.getById(id);
				
				list.setShopName(retailer.getShopName());
				list.setFirstName(retailer.getFirstName());
				list.setLastName(retailer.getLastName());
				list.setRetailerAddress(retailer.getRetailerAddress());
				list.setRetailerPincode(retailer.getRetailerPincode());
				list.setCityId(retailer.getCityId());
				list.setStateId(retailer.getStateId());
				
				retailerRepository.save(list);
				
				return list;
			}
	
			
	
	

}
