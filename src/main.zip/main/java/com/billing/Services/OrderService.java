package com.billing.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billing.Repository.OrderRepository;
import com.billing.entities.Order;


@Service
public class OrderService {
	
	@Autowired
	public OrderRepository orderRepository;
	
	public List<Order> getAllOrder()
	{
		List<Order> list=(List<Order>)this.orderRepository.findAll();
		return list;
		
	}
	
	//get the single Order by id
	
			public Order getOrderByid(Long id)
			{
				
				Order order=null;
				try 
				{
					 order = this.orderRepository.getById(id);
					 
					
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
				return order;
				
			}
			
			//Adding the State
			
			public Order addOrder(Order o)
			{
				Order result=orderRepository.save(o);
				return result;
				
			}
			

			 //delete Order
			public void deleteOrder(Long oid)
			{
				orderRepository.deleteById(oid);
			}
			
			//update the State
			
			public Order updateOrder(Order order, Long id)
			{
				
				Order list= orderRepository.getById(id);
				
				list.setAgencyId(order.getAgencyId());
				list.setDealerId(order.getDealerId());
				list.setRetailerId(order.getRetailerId());
				list.setGrossAmount(order.getGrossAmount());
				list.setDiscountAmount(order.getDiscountAmount());
				list.setNetAmount(order.getNetAmount());
				list.setOrderNumber(order.getOrderNumber());
				list.setOrderDate(order.getOrderDate());
				list.setOrderStatus(order.getOrderStatus());
				list.setOrderType(order.getOrderType());
				list.setOrderDuedate(order.getOrderDuedate());
				list.setPaymentType(order.getPaymentType());
				list.setPaymentDate(order.getPaymentDate());
				list.setPaymentStatus(order.getPaymentStatus());
				list.setPaymentid(order.getPaymentid());
				list.setPaymentMode(order.getPaymentMode());				
				
				orderRepository.save(list);
				
				return list;
			}
			

}
