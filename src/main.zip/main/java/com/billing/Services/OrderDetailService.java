package com.billing.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.billing.Repository.OrderDetailRepository;
import com.billing.entities.DealerRetailer;
import com.billing.entities.OrderDetail;

@Service
public class OrderDetailService {
	
	@Autowired
	private OrderDetailRepository orderDetailRepository;
	
	//Get All OrderDetails handler

	public List<OrderDetail> getAllOrderDetail()
	{
		List<OrderDetail>list=orderDetailRepository.findAll();
		return list;
	}
	
	//get the single OrderDetail by id
	
	public OrderDetail getOrderDetailByid(Long id)
	{
		
		OrderDetail orderDetail=null;
		try 
		{
			orderDetail = this.orderDetailRepository.getById(id);
			 
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return orderDetail;
		
	}
	
	//Adding the OrderDetail
	
	public OrderDetail addOrderDetail(OrderDetail o)
	{
		OrderDetail result=orderDetailRepository.save(o);
		return result;
		
	}
	
	//delete OrderDetail
	public OrderDetail deleteOrderDetail(Long oid)
	{
		OrderDetail  list= orderDetailRepository.getById(oid);
		orderDetailRepository.deleteById(oid);
		
		return list;
	}
	
	
	//update OrderDetails
	
	public OrderDetail updateOrderDetail(OrderDetail OrderDetail, Long id)
	{
		OrderDetail list= orderDetailRepository.getById(id);
		
		list.setProductId(OrderDetail.getProductId());
		list.setProductQty(OrderDetail.getProductQty());
		list.setProductAmount(OrderDetail.getProductAmount());
		list.setProductGrossamount(OrderDetail.getProductGrossamount());
		list.setProductDiscount(OrderDetail.getProductDiscount());
		list.setProductNetamount(OrderDetail.getProductNetamount());
	

		
		return list;
	}
	
	
	
}
