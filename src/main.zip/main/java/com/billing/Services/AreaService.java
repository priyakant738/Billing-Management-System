package com.billing.Services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billing.Repository.AreaRepository;
import com.billing.Repository.CityRepository;
import com.billing.entities.Area;
import com.billing.entities.City;
import com.billing.entities.State;


@Service
public class AreaService {
	
	@Autowired
	private AreaRepository areaRepository;
	
	
	
	public List<Area> getAllArea()
	{
		List<Area> list=(List<Area>)this.areaRepository.findAll();
		return list;
		
	}
	
	
	//Adding the Area
	
	public Area addArea(Area a)
	{
		Area result=areaRepository.save(a);
		return result;
				
	}
	
	//get the single Area by id
	
			public Area getAreaByid(Long id)
			{
				
				Area area=null;
				try 
				{
					 area = this.areaRepository.getById(id);
					 
					
				}
				catch (Exception e)
				{
					e.printStackTrace();
				}
				return area;
				
			}
			
			
			//delete area
			
			public void deleteArea(Long aid)
			{
				areaRepository.deleteById(aid);
			}
			
			//update the area
			
			public Area updateArea(Area area, Long id)
			{
				
				Area list = areaRepository.getById(id);
				list.setCity(area.getCity());
				list.setAreaCode(area.getAreaCode());
				list.setAreaName(area.getAreaName());
				return list;
			}

}
