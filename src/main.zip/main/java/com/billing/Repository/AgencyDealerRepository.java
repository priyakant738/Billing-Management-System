package com.billing.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billing.entities.AgencyDealer;

public interface AgencyDealerRepository extends JpaRepository <AgencyDealer, Long>{
	
	
	

}
